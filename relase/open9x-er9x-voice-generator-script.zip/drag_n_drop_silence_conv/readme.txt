USAGE:
drag-n-drop waws to the cmd icon (or shortcut)

trim parameter adjustable the bat file

REQUIRED:
SOX.exe